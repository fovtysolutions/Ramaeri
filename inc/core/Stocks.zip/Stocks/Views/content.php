<div class="container-xxl">
    <form id="<?= $formid ?>">
        <?php if ($editit) { ?>
            <input type="hidden" name="edit" value="<?= $editit ?>">
        <?php } ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card bg-light-subtle">
                    <div class="card-header border-0 justify-content-between p-4">
                        <div>
                            <h4>Add Stocks</h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-9 col-lg-8 ">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Basic Information</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="category-title" class="form-label">Category
                                        Name</label>
                                    <input type="text" id="category-title" class="form-control"
                                        placeholder="Enter category" name="category_id"
                                        value="<?= isset($detailsdata->category_id) ? $detailsdata->category_id : '' ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="category-title" class="form-label">Product Name</label>
                                    <input type="text" id="category-title" class="form-control"
                                        placeholder="Enter product" name="product_id"
                                        value="<?= isset($detailsdata->product_id) ? $detailsdata->product_id : '' ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="product-stock" class="form-label">Quantity</label>
                                    <input type="number" id="product-stock" class="form-control" placeholder="Quantity"
                                        name="quantity"
                                        value="<?= isset($detailsdata->quantity) ? $detailsdata->quantity : '' ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="product-id" class="form-label">Price</label>
                                    <input type="number" id="product-id" class="form-control"
                                        placeholder="Enter Your Price" name="price"
                                        value="<?= isset($detailsdata->price) ? $detailsdata->price : '' ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p-3 bg-light mb-3 rounded">
                    <div class="row justify-content-end g-2">
                        <div class="col-lg-2">
                            <a href="javascript:void(0)" id="savebtn" class="btn btn-outline-secondary w-100">Save
                                Change</a>
                        </div>
                        <div class="col-lg-2">
                            <a href="#!" onclick="history.back()" class="btn btn-primary w-100">Cancel</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3">
                <div class="card bg-light-subtle">
                    <div class="card-header border-0 justify-content-between p-4">
                        <div>
                            <h4>Stock Information</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<?php echo $this->section('script') ?>
<?php _ec($this->include('Core\Stocks\Views\submitit'), false) ?>
<?php echo $this->endSection() ?>