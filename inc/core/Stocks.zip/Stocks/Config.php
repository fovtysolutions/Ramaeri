<?php
return [
    'id' => 'stocks',
    'folder' => 'core',
    'name' => 'Stocks',
    'desc' => 'Customize system interface',
    'icon' => 'typcn typcn-user',
    'color' => '#28abf5',
    'require' => true,
    'position' => 3000,
];